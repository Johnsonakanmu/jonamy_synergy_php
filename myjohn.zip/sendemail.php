<?php
session_start();

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

if (isset($_POST['submitContact'])) {
  $username = $_POST['username'];
  $email = $_POST['email'];
  $phone = $_POST['phone'];
  $subject = $_POST['subject'];
  $message = $_POST['message'];

  //Create an instance; passing `true` enables exceptions
  $mail = new PHPMailer(true);

  try {

    $mail->isMail();

    //Recipients
    $mail->setFrom('johnsonakanmu2017@gmail.com', 'From Jonahet & Co');
    $mail->addAddress('johnsonakanmu2017@gmail.com', 'From Jonahet & Co');     //Add a recipient

    //Content
    $mail->isHTML(true);                                  //Set email format to HTML
    $mail->Subject = 'Here is the subject';
    $mail->Body    = '<h3>Hello, you got a new enquiry</h3>
                          <h4>username: ' . $username . '</h4>
                          <h4>email: ' . $email . '</h4>
                          <h4>phone: ' . $phone . '</h4>
                          <h4>subject: ' . $subject . '</h4>
                          <h4>message: ' . $message . '</h4>';

    if ($mail->send()) {
      $_SESSION['status'] = "Thank you for contacting us - Team Jonahnet";
      header("Location: {$_SERVER["HTTP_REFERER"]}");
      exit(0);
    } else {
      $_SESSION['status'] = "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
      header("Location: {$_SERVER["HTTP_REFERER"]}");
      exit(0);
    }
  } catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
  }
} else {
  header('Location: index.php');
  exit(0);
}